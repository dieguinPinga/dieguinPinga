// Completar con tus redes WiFi (se prueban en orden).
// wifi_secrets.h esta en .gitignore: NO se sube al repositorio.
#pragma once
#include "feeds.h"

static const WifiNet WIFI_LIST[] = {
  { "MiRed",        "mi_clave"   },
  { "OtraRed",      "otra_clave" },
};
