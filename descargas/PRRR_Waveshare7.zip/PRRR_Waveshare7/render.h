// Dibujo por pixeles del grafico, SMA, rio de flujo y waterfall.
// Funciones del sketch original, ahora sobre Canvas565 (coordenadas del lienzo).
#pragma once
#include "canvas565.h"

// Nivel de diagnostico activo (1..5, ver prrr_config.h). Solo lo cambia loop().
extern int g_diagLevel;

// Diagnostico: tiempos de dibujo en el buffer trasero (microsegundos)
struct RenderDiag {
  uint32_t fullCount, fullMaxUs;
  uint64_t fullSumUs;
  uint32_t tailCount, tailMaxUs;
};
extern RenderDiag renderDiag;

void renderBegin(Canvas565* canvas);
void drawStaticFrames();

int chartYForPrice(double price, double minP, double maxP, int y, int h);

void drawChartArea();            // redibujado completo del grafico (precio + SMA)
void drawTailRegionDefault();    // solo la ultima columna (actualizacion parcial)
void drawLivePriceTailDefault(); // marcador de precio en vivo + escala de ticks
void drawFlowBandArea();         // rio de flujo
void drawWaterfallArea();        // waterfall historico + frente en vivo
